function [A] = updateA(C)

format compact;
% run vl_setupnn in the MatConvNet directory
run matlab/vl_setupnn
%-------------------------------------------------------------------------
  % parameter setting
%-------------------------------------------------------------------------

% global sigmas; % input noise level
useGPU      = 1; % CPU or GPU. 
nch = 25;   %number of channel of the input volume
num_eval = 1;  %number of running

%-------------------------------------------------------------------------
  % load model
%-------------------------------------------------------------------------

load(fullfile('BestModel','best_model')); %load model
net.layers = net.layers(1:end-1);
net = vl_simplenn_tidy(net);

if useGPU
    net = vl_simplenn_move(net, 'gpu') ;
end

%vl_simplenn_display(net);
% save('test.mat','C');
% load('test');
label=[];
label=C;
[w,h,depth] = size(label);
%-------------------------------------------------------------------------
  % pre-processing
%-------------------------------------------------------------------------
    K = nch-1; 
    nz = depth + K;
    data = zeros(w,h,nz);
    order_init = (K/2+1):-1:2;
    order_final = (depth-1):-1:(depth-K/2);
    data(:,:,1:K/2) = label(:,:,order_init);
    data(:,:,(K/2 + 1):(end-K/2)) = label;
    data(:,:,(end-K/2+1):end) = label(:,:,order_final);
%     inputs = single(data);
% sigmas = 35.5/255;
inputs = data;
    if mod(w,2)==1
        inputs = cat(1,inputs, inputs(end,:,:)) ;
    end
    if mod(h,2)==1
        inputs = cat(2,inputs, inputs(:,end,:)) ;
    end

    if useGPU
        inputs = gpuArray(inputs);
    end
    
%     max_in = max(inputs(:));min_in = min(inputs(:));
%     inputs = (inputs-min_in)/(max_in-min_in);

%     sigmas = 0.1;%100/255
    [nx,ny,nz] = size(inputs);
    output_img = zeros(nx,ny,depth,'gpuArray');
    
%-------------------------------------------------------------------------
  % denoising process
%-------------------------------------------------------------------------  
    
    for z = 1 : depth
        
        input = inputs(:,:,z:z+K);
       
        % perform denoising
        % res    = vl_simplenn(net,input,[],[],'conserveMemory',true,'mode','test'); % matconvnet default
        res    = vl_net_concise(net, input);    % concise version of vl_simplenn for testing (faster) 
        output = res(end).x;
        output_img(:,:,z) = output;
    end
    
     
    if mod(w,2)==1
        output_img = output_img(1:end-1,:,:);
        inputs  = inputs(1:end-1,:,:);
    end
    if mod(h,2)==1
        output_img = output_img(:,1:end-1,:);
        inputs  = inputs(:,1:end-1,:);
    end
    
    if useGPU
        A = gather(output_img);
        inputs  = gather(inputs);
    end
