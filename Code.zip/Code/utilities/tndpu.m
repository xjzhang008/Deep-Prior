function [L,S,obj,err,iter,iterpsnr2] = tndpu(X,lambda,opts,Omega,p,t,U,HPI)

% Solve the Tensor Robust Principal Component Analysis based on Tensor Nuclear Norm problem by ADMM
%
% min_{L,S} ||L||_*+lambda*||S||_1, s.t. X=L+S P_Omega(L+S) = P_Omega(X)

%
% ---------------------------------------------
% Input:
%       X       -    d1*d2*d3 tensor
%       lambda  -    >0, parameter
%       opts    -    Structure value in Matlab. The fields are
%           opts.tol        -   termination tolerance
%           opts.max_iter   -   maximum number of iterations
%           opts.mu         -   stepsize for dual variable updating in ADMM
%           opts.max_mu     -   maximum stepsize
%           opts.rho        -   rho>=1, ratio used to increase mu
%           opts.DEBUG      -   0 or 1
%
% Output:
%       L       -    d1*d2*d3 tensor
%       S       -    d1*d2*d3 tensor
%       obj     -    objective function value
%       err     -    residual 
%       iter    -    number of iterations
%
% version 1.0 - 19/06/2016
%
% Written by Canyi Lu (canyilu@gmail.com)
% 
% References: 
% [1] Canyi Lu, Jiashi Feng, Yudong Chen, Wei Liu, Zhouchen Lin and Shuicheng
%     Yan, Tensor Robust Principal Component Analysis with A New Tensor Nuclear
%     Norm, arXiv preprint arXiv:1804.03728, 2018
% [2] Canyi Lu, Jiashi Feng, Yudong Chen, Wei Liu, Zhouchen Lin and Shuicheng
%     Yan, Tensor Robust Principal Component Analysis: Exact Recovery of Corrupted 
%     Low-Rank Tensors via Convex Optimization, arXiv preprint arXiv:1804.03728, 2018
%

% tol = 1e-2; 
% max_iter = 200;
rho = 1;
% mu = 1e-4;
max_mu = 1e10;
DEBUG = 0;
global sigmas
minsigma = 0.01;
if isfield(opts,'sigma');       sigma = opts.sigma;                  else  sigma = 0.1;                end


if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'max_iter');    max_iter = opts.max_iter;    end
if isfield(opts, 'rho');         rho = opts.rho;              end
if isfield(opts, 'mu');          mu = opts.mu;                end
if isfield(opts, 'max_mu');      max_mu = opts.max_mu;        end
if isfield(opts, 'DEBUG');       DEBUG = opts.DEBUG;          end
unobserved = isnan(X);
X(unobserved) = 0;
normX = norm(X(:));
[w, h, c] = size(X);
dim = size(X);
L = zeros(dim);
S = L;
Y1 = L;
Y2 = L;
A = L;
Z = L;
useGPU = 1;
eta=[];
iter = 0;
iterpsnr2=[];
process = {};
for iter = 1 : max_iter
    iterpsnr2(iter)= psnr_s1(HPI(:),L(:));
    % update Z21
    Z21 = -L-S-Y2/mu;
    Z21(Omega) =(1/(p+mu))*(mu*(X(Omega)-L(Omega)-S(Omega))-Y2(Omega));
    % update L
    M = 1/2*(-Z21-S+X-Y2/mu+A-Y1/mu);
%    [L1,tnn,trank] = prox_dcttnn(M,1/mu);
% %     L1 = dct(M,[],3);
%     L1= tenmat(L1,[3]);
%     L1 = L1.data;
%     [UU D V] = svd(L1,'econ');
    UU=U;
    [L1,tnnL,trank]=prox_utnn(UU,M,1/(2*mu));
    
    % update Z
    Z1 = -L1-S-Y2/mu;
    Z1(Omega) =(1/(p+mu))*(mu*(X(Omega)-L1(Omega)-S(Omega))-Y2(Omega));
    % update S
%     S = -L+X-Y1/mu;
    S1= prox_l1(-L1+X-Z1-Y2/mu,lambda/mu);
%     % update Z
%     Z = -L-S-Y2/mu;
%     Z(Omega) =(1/(p+mu))*(mu*(X(Omega)-L(Omega)-S(Omega))-Y2(Omega));
    % update A
%     C=[];
%     C=unorigami(L+Y2/mu,[w h c]);
%     save('test.mat','C');
    
    C = (L1+Y1/mu);
    A1 = updateA(C);
  
    dY = L1+S1+Z1-X;
    Y21 = Y2 +t*mu*dY;
    Y11 = Y1 +t*mu*(L1-A1);
%     dY(unobserved) = 0;
   % chgL = max(abs(Lk(:)-L(:)));
    %chgS = max(abs(Sk(:)-S(:)));
    %chg = max([ chgL chgS max(abs(dY(:))) ]);
    
   [LL,tnnL,trank]=prox_utnn(UU,L1 - Y11 - Y21,1);
   etall = L1 - LL;
   etal = norm(etall(:))/(1 + norm(L1(:)) + norm(Y11(:)) + norm(Y21(:)));
   AA=updateA(A1+Y11);
   etaa = A1 - AA;
   etaa = norm(etaa(:))/(1+ norm(A1(:)) + norm(Y11(:)));
   
   etas = S1 - prox_l1(S1 - Y2,lambda);
   etas = norm(etas(:))/(1 + norm(S1(:)) + norm(Y2(:)));
   Z11=zeros(dim);
   Z11(Omega)=Z1(Omega);
   PZ1 = p*Z11;
   etaz = PZ1 + Y21;
   etaz = norm(etaz(:))/(1 + norm(PZ1(:)) + norm(Y21(:)));
   
   
   eta1 = L1 + S1 + Z1 - X;
   eta1 = norm(eta1(:))/(1 + norm(X(:)));
   
   eta2 = L1-A1;
   eta2 = norm(eta2(:))/(1 + norm(L1(:)) + norm(A1(:)));
   
   
   etap = max([etal,etaa, etas, etaz]); 
   etad = max([eta1, eta2]);
   eta = [etap, etad];  
    if DEBUG
        if iter == 1 || mod(iter, 10) == 0
            obj = tnnL+lambda*norm(S(:),1);
%             err1 = abs(norm(L(:)-Llast(:))/norm(Llast(:)));
            etal=etal;
            normll=norm(etall(:));
            normy1=norm(Y11(:));
            normy2=norm(Y21(:));
            norml=norm(L1(:));
            etas=etas;
            etaz=etaz;
            eta1=eta1;
            eta2=eta2;
            disp(['iter ' num2str(iter) ...
                    ', obj=' num2str(obj) ', maxeta=' num2str(max(eta))])
        end
    end
    if max(eta) < tol
        break;
    end 
    %% update variable
   Y1 = Y11;
   Y2 = Y21;
   L = L1;
   S = S1;
   A = A1;
    if rho ~= 1 && iter>20
    sigma = max(minsigma,sigma/rho);
    end
end
err=max(eta);
