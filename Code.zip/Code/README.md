# code of Robust Low Transformed Multi-Rank Tensor Completion With Deep Prior Regularization for Multi-Dimensional Image Recovery
********************************************************************************
Robust Low Transformed Multi-Rank Tensor Completion With Deep Prior Regularization for Multi-Dimensional Image Recovery
********************************************************************************

 Copyright:     Yao Li, Duo Qiu, and Xiongjun Zhang
                   
********************************************************************************
********************************************************************************
Details:
  
  Before running this code you should download matconvnet-1.0-beta25 from http://www.vlfeat.org/matconvnet/
  More detail can be found in [1],[2]
  


The training network for hyperspectral images follows from reference [1].
  [1] A single model CNN for hyperspectral image denoising
      A. Maffei, J. M. Haut, M. E. Paoletti, J. Plaza, L. Bruzzone, and A. Plaza
      IEEE Trans. Geosci. Remote Sens.
********************************************************************************

