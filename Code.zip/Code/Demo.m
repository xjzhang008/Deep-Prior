clc
clear
addpath(genpath(cd))
addpath('tensor_toolbox_2.6');
addpath(genpath('utilities'));
randn('seed',2013); randn('seed',2013);
Enlarge_Factor = 1;
load('HPI.mat');
% X=double(B);
% X = A/max(A(:));
% X=double(X);
% X =X/255;
X=HPI;
HPI=X;
label = X;
% p = 1;%% 0-2֮��
Img_Size = size(X);
% Figure_Width = Img_Size(2)*Enlarge_Factor;
% Figure_Height = Img_Size(1)*Enlarge_Factor;
% Xn = X;

[n1,n2,n3] = size(X);
%%������������
level = 0.1;
Xn = imnoise(X,'salt & pepper',level);
%%���Ӹ�˹����
s = 0.05;
Xn7 = Xn+s*randn([n1,n2,n3]);
SR = 0.4;           %������
Img_Size = size(Xn7);
% Generate known data
P           = round(SR*prod(Img_Size));      % prod���س˻�
Omega       = randsample(prod(Img_Size),P);
[Omega,~]   = sort(Omega);   % Known = Omega
% Missing data
Known_Entries       = Xn7(Omega);
  % Observed data
X_Observed          = zeros(Img_Size);
X_Observed(Omega)   = Known_Entries;

alpha=0.01;
opts.mu = 1;
opts.sigma=sqrt(alpha/opts.mu);
opts.tol = 0.0005;
opts.rho = 1;
opts.max_iter = 40;
opts.DEBUG = 1;
p =10;      %%% rho                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ;
t= 1.618;   %%% tau
[n1,n2,n3] = size(Xn);                                                                                                      
lambda =55/sqrt(max(n1,n2)*n3);

fprintf('DCT \n');

tic;
[Xd,E,obj,err,iter] = tndpdct(X_Observed,lambda,opts,Omega,p,t);
toc 
psnr = psnr_s1(X(:),Xd(:))
% XX=X*255;
XX=X*255;
XXd=Xd*255;
ssim = ssim3d(XX,XXd)

% psnrhtdnpd=[];
% for i=1:156
%     A1=X(:,:,i);
%     A2=Xd(:,:,i);
%     maxP=max(abs(A1(:)));
%     psnrhtndpd(i)=PSNR(A1,A2,maxP);
% end
%%%%%-U-%%%%%%%%%
fprintf('Unitary transform\n');
O = Unfold(Xd,[n1 n2 n3],3);
[U D V] = svd(O,'econ');
clear D  V
% lambda =20/sqrt(max(n1,n2)*n3);
% p = 10;
% alpha=0.01;
% opts.mu = 1.4;
% opts.sigma=sqrt(alpha/opts.mu);
tic;
[Xu,E,obj,err,iter,iterpsnr2] = tndpu(X_Observed,lambda,opts,Omega,p,t,U,HPI);
toc  
psnr1 = psnr_s1(X(:),Xu(:))
% XX=X*255;
XX=X*255;
XXu=Xu*255;
ssim1 = ssim3d(XX,XXu)
% % X4=Xd(:,:,23);
% % imshow(X4/max(X4(:)),'border','tight','initialmagnification','fit')
% % set(gcf,'Position',[0,0,256,256]);
% X4=Xu(:,:,90);
% imshow(X4/max(X4(:)),'border','tight','initialmagnification','fit')
% set(gcf,'Position',[0,0,217,181]);
% 
% htndpu=[];
% for i=1:156
%     AA1=X(:,:,i);
%     AA2=Xu(:,:,i);
%     maxP=max(abs(AA1(:)));
%     htndpu(i)=PSNR(AA1,AA2,maxP);
% end
